﻿namespace TeisterMask.Data
{
    public static class Configuration
    {
        public static string ConnectionString = @"Server=DESKTOP-MANIFEK\SQLEXPRESS;Database=TeisterMask;Trusted_Connection=True";
    }
}
